 
 Import-Module SQLPS -DisableNameChecking
$PRIMARY=(New-Object Microsoft.SqlServer.Management.Smo.Server($ComputerName)).AvailabilityGroups[0].PrimaryReplicaServerName
 
$SERVERNAME=$env:COMPUTERNAME
if($PRIMARY-eq$SERVERNAME)
{
    $databasename="select name  from sys.databases where name like 'test_sandeep4567_%' and name not in ('dba','util','master','model','msdb','tempdb')"
    $db=invoke-sqlcmd -Query $databasename -ServerInstance $env:COMPUTERNAME
    
    foreach($dba in $db)
    {
        $dbname=$dba.name
        #write-host $dbname
        $backupquery1="exec dba.dbo.usp_remove_user_login @dbname='$dbname'
        exec dba.dbo.usp_Backup_db @dbname= '$dbname',@comment='newbackup',@bu_type='full'
        If exists (select * from sys.dm_hadr_database_replica_states where database_id=db_id('$dbname'))
        BEGIN
        ALTER AVAILABILITY GROUP AG1 REMOVE DATABASE $dbname
        drop database $dbname
        END
        else
        begin
        drop database $dbname
        end"
            write-host  $backupquery1
        invoke-sqlcmd -Query $backupquery1 -ServerInstance $env:COMPUTERNAME
 
 
 
        Get-ClusterNode|ForEach-Object {
            if($Primary -ne $_.Name)
            {
 
                $drop="if exists(select * from sys.databases where name = '$dbname')
                begin
                drop database $dbname
                end"
                WRITE-HOST $drop
 
                invoke-sqlcmd -Query $drop �ServerInstance $_.name
 
            }
 
        }
    }
}
 
